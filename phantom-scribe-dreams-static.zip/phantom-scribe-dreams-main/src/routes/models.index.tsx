import { createFileRoute } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { SiteHeader } from "@/components/site-header";
import { SiteFooter } from "@/components/site-footer";
import { ModelsShowcase } from "@/components/models-showcase";

export const Route = createFileRoute("/models/")({
  component: ModelsPage,
});

function ModelsPage() {
  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <main className="pt-32">
        <section className="px-6 md:px-12 py-16">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="mx-auto max-w-[1500px]"
          >
            <div className="text-[11px] tracking-luxury uppercase text-gold mb-4">The Range</div>
            <h1 className="text-6xl md:text-7xl">Models</h1>
          </motion.div>
        </section>
        <ModelsShowcase />
      </main>
      <SiteFooter />
    </div>
  );
}
