import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { useState, type FormEvent } from "react";
import { ArrowRight, Loader2 } from "lucide-react";
import { supabase } from "@/lib/supabase";
import heroImg from "@/assets/rolls-hero.jpg";

export const Route = createFileRoute("/signin")({
  component: SignIn,
});

function SignIn() {
  const navigate = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const onSubmit = async (e: FormEvent) => {
    e.preventDefault();
    setError(null);
    setLoading(true);
    try {
      const { error } = await supabase.auth.signInWithPassword({ email, password });
      if (error) throw error;
      navigate({ to: "/" });
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unable to sign in. Add your Supabase credentials in src/lib/supabase.ts");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen grid grid-cols-1 lg:grid-cols-2 bg-background">
      {/* Visual side */}
      <div className="relative hidden lg:block overflow-hidden gradient-radial-dark">
        <motion.img
          src={heroImg}
          alt=""
          initial={{ scale: 1.1, opacity: 0 }}
          animate={{ scale: 1, opacity: 0.85 }}
          transition={{ duration: 1.6, ease: [0.16, 1, 0.3, 1] }}
          className="absolute inset-0 h-full w-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-r from-background/40 to-background" />
        <div className="absolute bottom-12 left-12 right-12">
          <div className="text-[11px] tracking-luxury uppercase text-gold mb-3">Owner Portal</div>
          <h1 className="text-5xl font-display leading-tight">An invitation<br />to the extraordinary.</h1>
        </div>
      </div>

      {/* Form side */}
      <div className="flex flex-col justify-center px-8 md:px-20 py-16 relative">
        <Link to="/" className="absolute top-8 left-8 text-[11px] tracking-luxury uppercase text-muted-foreground hover:text-gold transition-colors">
          ← Back
        </Link>

        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8 }}
          className="max-w-sm w-full mx-auto"
        >
          <div className="font-display text-3xl text-gold tracking-wider mb-1">RR</div>
          <h2 className="text-4xl font-display mb-2">Sign In</h2>
          <p className="text-sm text-muted-foreground mb-10">
            Enter your details to access your private collection.
          </p>

          <form onSubmit={onSubmit} className="space-y-6">
            <div>
              <label className="text-[10px] tracking-luxury uppercase text-muted-foreground">Email</label>
              <input
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                className="mt-2 w-full bg-transparent border-b border-border focus:border-gold outline-none py-3 text-foreground transition-colors"
                placeholder="you@domain.com"
              />
            </div>
            <div>
              <label className="text-[10px] tracking-luxury uppercase text-muted-foreground">Password</label>
              <input
                type="password"
                required
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="mt-2 w-full bg-transparent border-b border-border focus:border-gold outline-none py-3 text-foreground transition-colors"
                placeholder="••••••••"
              />
            </div>

            {error && (
              <motion.p
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="text-xs text-destructive border-l-2 border-destructive pl-3"
              >
                {error}
              </motion.p>
            )}

            <button
              type="submit"
              disabled={loading}
              className="group w-full flex items-center justify-between bg-gold text-gold-foreground px-6 py-4 text-[11px] tracking-luxury uppercase hover:bg-foreground transition-colors disabled:opacity-60"
            >
              <span>{loading ? "Signing in" : "Sign In"}</span>
              {loading ? <Loader2 className="h-4 w-4 animate-spin" /> : <ArrowRight className="h-4 w-4 group-hover:translate-x-1 transition-transform" />}
            </button>
          </form>

          <div className="mt-8 flex justify-between text-[10px] tracking-luxury uppercase text-muted-foreground">
            <a className="hover:text-gold cursor-pointer transition-colors">Forgot password</a>
            <a className="hover:text-gold cursor-pointer transition-colors">Request access</a>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
