/* eslint-disable */
// @ts-nocheck
// noinspection JSUnusedGlobalSymbols

import { Route as rootRouteImport } from './routes/__root'
import { Route as SigninRouteImport } from './routes/signin'
import { Route as IndexRouteImport } from './routes/index'
import { Route as BrandRouteImport } from './routes/brand'
import { Route as OwnershipRouteImport } from './routes/ownership'
import { Route as ExperienceRouteImport } from './routes/experience'
import { Route as ModelsLayoutRouteImport } from './routes/models'
import { Route as ModelsIndexRouteImport } from './routes/models.index'
import { Route as ModelsGhostRouteImport } from './routes/models/ghost'
import { Route as ModelsCullinanRouteImport } from './routes/models/cullinan'
import { Route as ModelsSpectreRouteImport } from './routes/models/spectre'

// ── Flat routes (children of root) ──────────────────────────────────────────
const SigninRoute = SigninRouteImport.update({
  id: '/signin', path: '/signin', getParentRoute: () => rootRouteImport,
} as any)

const IndexRoute = IndexRouteImport.update({
  id: '/', path: '/', getParentRoute: () => rootRouteImport,
} as any)

const BrandRoute = BrandRouteImport.update({
  id: '/brand', path: '/brand', getParentRoute: () => rootRouteImport,
} as any)

const OwnershipRoute = OwnershipRouteImport.update({
  id: '/ownership', path: '/ownership', getParentRoute: () => rootRouteImport,
} as any)

const ExperienceRoute = ExperienceRouteImport.update({
  id: '/experience', path: '/experience', getParentRoute: () => rootRouteImport,
} as any)

// ── Models layout (parent of all /models/* routes) ───────────────────────────
const ModelsLayoutRoute = ModelsLayoutRouteImport.update({
  id: '/models', path: '/models', getParentRoute: () => rootRouteImport,
} as any)

// ── Models children ──────────────────────────────────────────────────────────
const ModelsIndexRoute = ModelsIndexRouteImport.update({
  id: '/models/', path: '/', getParentRoute: () => ModelsLayoutRoute,
} as any)

const ModelsGhostRoute = ModelsGhostRouteImport.update({
  id: '/models/ghost', path: '/ghost', getParentRoute: () => ModelsLayoutRoute,
} as any)

const ModelsCullinanRoute = ModelsCullinanRouteImport.update({
  id: '/models/cullinan', path: '/cullinan', getParentRoute: () => ModelsLayoutRoute,
} as any)

const ModelsSpectreRoute = ModelsSpectreRouteImport.update({
  id: '/models/spectre', path: '/spectre', getParentRoute: () => ModelsLayoutRoute,
} as any)

// ── Wire children to parents ─────────────────────────────────────────────────
const ModelsLayoutRouteWithChildren = ModelsLayoutRoute._addFileChildren([
  ModelsIndexRoute,
  ModelsGhostRoute,
  ModelsCullinanRoute,
  ModelsSpectreRoute,
])

// ── Type declarations ─────────────────────────────────────────────────────────
export interface FileRoutesByFullPath {
  '/': typeof IndexRoute
  '/signin': typeof SigninRoute
  '/brand': typeof BrandRoute
  '/ownership': typeof OwnershipRoute
  '/experience': typeof ExperienceRoute
  '/models': typeof ModelsLayoutRoute
  '/models/': typeof ModelsIndexRoute
  '/models/ghost': typeof ModelsGhostRoute
  '/models/cullinan': typeof ModelsCullinanRoute
  '/models/spectre': typeof ModelsSpectreRoute
}
export interface FileRoutesByTo {
  '/': typeof IndexRoute
  '/signin': typeof SigninRoute
  '/brand': typeof BrandRoute
  '/ownership': typeof OwnershipRoute
  '/experience': typeof ExperienceRoute
  '/models': typeof ModelsLayoutRoute
  '/models/': typeof ModelsIndexRoute
  '/models/ghost': typeof ModelsGhostRoute
  '/models/cullinan': typeof ModelsCullinanRoute
  '/models/spectre': typeof ModelsSpectreRoute
}
export interface FileRoutesById {
  __root__: typeof rootRouteImport
  '/': typeof IndexRoute
  '/signin': typeof SigninRoute
  '/brand': typeof BrandRoute
  '/ownership': typeof OwnershipRoute
  '/experience': typeof ExperienceRoute
  '/models': typeof ModelsLayoutRouteWithChildren
  '/models/': typeof ModelsIndexRoute
  '/models/ghost': typeof ModelsGhostRoute
  '/models/cullinan': typeof ModelsCullinanRoute
  '/models/spectre': typeof ModelsSpectreRoute
}
export interface FileRouteTypes {
  fileRoutesByFullPath: FileRoutesByFullPath
  fullPaths: '/' | '/signin' | '/brand' | '/ownership' | '/experience' | '/models' | '/models/' | '/models/ghost' | '/models/cullinan' | '/models/spectre'
  fileRoutesByTo: FileRoutesByTo
  to: '/' | '/signin' | '/brand' | '/ownership' | '/experience' | '/models' | '/models/' | '/models/ghost' | '/models/cullinan' | '/models/spectre'
  id: '__root__' | '/' | '/signin' | '/brand' | '/ownership' | '/experience' | '/models' | '/models/' | '/models/ghost' | '/models/cullinan' | '/models/spectre'
  fileRoutesById: FileRoutesById
}
export interface RootRouteChildren {
  IndexRoute: typeof IndexRoute
  SigninRoute: typeof SigninRoute
  BrandRoute: typeof BrandRoute
  OwnershipRoute: typeof OwnershipRoute
  ExperienceRoute: typeof ExperienceRoute
  ModelsLayoutRoute: typeof ModelsLayoutRouteWithChildren
}

declare module '@tanstack/react-router' {
  interface FileRoutesByPath {
    '/': { id: '/'; path: '/'; fullPath: '/'; preLoaderRoute: typeof IndexRouteImport; parentRoute: typeof rootRouteImport }
    '/signin': { id: '/signin'; path: '/signin'; fullPath: '/signin'; preLoaderRoute: typeof SigninRouteImport; parentRoute: typeof rootRouteImport }
    '/brand': { id: '/brand'; path: '/brand'; fullPath: '/brand'; preLoaderRoute: typeof BrandRouteImport; parentRoute: typeof rootRouteImport }
    '/ownership': { id: '/ownership'; path: '/ownership'; fullPath: '/ownership'; preLoaderRoute: typeof OwnershipRouteImport; parentRoute: typeof rootRouteImport }
    '/experience': { id: '/experience'; path: '/experience'; fullPath: '/experience'; preLoaderRoute: typeof ExperienceRouteImport; parentRoute: typeof rootRouteImport }
    '/models': { id: '/models'; path: '/models'; fullPath: '/models'; preLoaderRoute: typeof ModelsLayoutRouteImport; parentRoute: typeof rootRouteImport }
    '/models/': { id: '/models/'; path: '/'; fullPath: '/models/'; preLoaderRoute: typeof ModelsIndexRouteImport; parentRoute: typeof ModelsLayoutRouteImport }
    '/models/ghost': { id: '/models/ghost'; path: '/ghost'; fullPath: '/models/ghost'; preLoaderRoute: typeof ModelsGhostRouteImport; parentRoute: typeof ModelsLayoutRouteImport }
    '/models/cullinan': { id: '/models/cullinan'; path: '/cullinan'; fullPath: '/models/cullinan'; preLoaderRoute: typeof ModelsCullinanRouteImport; parentRoute: typeof ModelsLayoutRouteImport }
    '/models/spectre': { id: '/models/spectre'; path: '/spectre'; fullPath: '/models/spectre'; preLoaderRoute: typeof ModelsSpectreRouteImport; parentRoute: typeof ModelsLayoutRouteImport }
  }
}

const rootRouteChildren: RootRouteChildren = {
  IndexRoute,
  SigninRoute,
  BrandRoute,
  OwnershipRoute,
  ExperienceRoute,
  ModelsLayoutRoute: ModelsLayoutRouteWithChildren,
}

export const routeTree = rootRouteImport
  ._addFileChildren(rootRouteChildren)
  ._addFileTypes<FileRouteTypes>()
