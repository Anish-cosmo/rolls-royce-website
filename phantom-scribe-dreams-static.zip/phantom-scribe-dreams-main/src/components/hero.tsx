import { motion } from "framer-motion";
import { ArrowRight, Gauge, Cog, Settings2 } from "lucide-react";
import heroImg from "@/assets/rolls-hero.jpg";
import heroMobileImg from "@/assets/rolls-phantom-mobile.jpg";

const stats = [
  { icon: Gauge, n: "01", label: "Top Speed", text: "The Phantom delivers a refined top speed of 250 km/h with absolute composure." },
  { icon: Cog, n: "02", label: "Engine", text: "A 6.75L twin-turbocharged V12 producing 563 hp of effortless power." },
  { icon: Settings2, n: "03", label: "Steering", text: "Planar suspension and self-leveling air system for a magic-carpet ride." },
];

export function Hero() {
  return (
    <section className="relative overflow-hidden gradient-radial-dark">

      {/* ── MOBILE HERO (hidden on md+) ─────────────────────────────────── */}
      <div className="md:hidden relative w-full h-screen">
        {/* Full-bleed 9:16 image */}
        <img
          src={heroMobileImg}
          alt="Rolls-Royce Phantom"
          className="absolute inset-0 w-full h-full object-cover object-center"
        />

        {/* Dark overlay so text is readable */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/10 to-black/30" />

        {/* Vertical "PHANTOM" — right side, each letter stacked with equal gap, like SHEE reference */}
        <motion.div
          initial={{ opacity: 0, x: 30 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 1.2, delay: 0.4, ease: [0.16, 1, 0.3, 1] }}
          className="absolute top-0 right-0 h-full flex flex-col justify-center items-center select-none pointer-events-none"
          style={{ paddingTop: "8vh", paddingBottom: "22vh", paddingRight: "4vw" }}
        >
          {"PHANTOM".split("").map((letter, i) => (
            <motion.span
              key={i}
              initial={{ opacity: 0, x: 20 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 0.7, delay: 0.5 + i * 0.08, ease: [0.16, 1, 0.3, 1] }}
              className="block font-display text-white leading-none"
              style={{
                fontSize: "clamp(28px, 8.5vw, 52px)",
                marginBottom: "clamp(10px, 3.5vw, 22px)",
                opacity: 0.93,
                fontWeight: 400,
              }}
            >
              {letter}
            </motion.span>
          ))}
        </motion.div>

        {/* Bottom-left: tagline + CTA */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 1, delay: 0.7 }}
          className="absolute bottom-10 left-6"
        >
          <p
            className="font-display text-white leading-snug mb-4"
            style={{ fontSize: "clamp(13px, 3.8vw, 18px)", letterSpacing: "0.01em", fontWeight: 300 }}
          >
            Rolls-Royce like<br />you have never seen.
          </p>
          <button
            className="inline-flex items-center text-white"
            style={{ fontSize: "clamp(9px, 2.8vw, 11px)", letterSpacing: "0.18em", textTransform: "uppercase", textDecoration: "underline", textUnderlineOffset: "4px", fontFamily: "inherit" }}
          >
            Learn More
          </button>
        </motion.div>

      </div>

      {/* ── DESKTOP HERO (hidden below md) ──────────────────────────────── */}
      <div className="hidden md:block relative min-h-screen">
        {/* Giant background word */}
        <motion.h2
          initial={{ opacity: 0, scale: 1.05 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1.6, ease: [0.16, 1, 0.3, 1] }}
          className="absolute inset-x-0 top-[18%] text-center text-[18vw] leading-none font-display text-stroke-faint pointer-events-none select-none"
        >
          PHANTOM
        </motion.h2>

        {/* Car image */}
        <motion.div
          initial={{ y: 60, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 1.2, delay: 0.3, ease: [0.16, 1, 0.3, 1] }}
          className="absolute inset-x-0 top-[18%] flex justify-center"
        >
          <img
            src={heroImg}
            alt="Rolls-Royce Phantom"
            width={1920}
            height={1080}
            className="w-[90%] max-w-[1400px] object-contain drop-shadow-[0_40px_80px_rgba(0,0,0,0.7)]"
          />
        </motion.div>

        {/* Bottom panel */}
        <div className="absolute inset-x-0 bottom-0 px-12 pb-10">
          <div className="mx-auto max-w-[1500px] grid grid-cols-[1fr_2fr] gap-10 items-end">
            <motion.div
              initial={{ opacity: 0, x: -40 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 1, delay: 0.8 }}
            >
              <h1 className="text-4xl md:text-5xl leading-[1.05]">
                Rolls-Royce like<br />you've never seen.
              </h1>
              <button className="group mt-6 inline-flex items-center gap-3 text-[11px] tracking-luxury uppercase text-gold">
                Learn More
                <span className="h-px w-10 bg-gold transition-all group-hover:w-16" />
                <ArrowRight className="h-3 w-3" />
              </button>
            </motion.div>

            <div className="grid grid-cols-3 gap-6">
              {stats.map((s, i) => (
                <motion.div
                  key={s.n}
                  initial={{ opacity: 0, y: 30 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ duration: 0.8, delay: 1 + i * 0.15 }}
                  className="relative"
                >
                  <div className="text-7xl font-display text-stroke-faint absolute -top-4 right-0 leading-none">
                    {s.n}
                  </div>
                  <s.icon className="h-6 w-6 text-gold mb-3 relative" />
                  <div className="text-[10px] tracking-luxury uppercase text-foreground/90 mb-2 relative">{s.label}</div>
                  <p className="text-xs text-muted-foreground leading-relaxed relative max-w-[200px]">{s.text}</p>
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </div>

    </section>
  );
}
