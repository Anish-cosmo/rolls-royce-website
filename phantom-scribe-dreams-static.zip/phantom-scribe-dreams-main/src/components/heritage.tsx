import { motion } from "framer-motion";

const FACTS = [
  { n: "120+", l: "Years of Heritage" },
  { n: "563", l: "Horsepower V12" },
  { n: "44", l: "Bespoke Workshops" },
  { n: "∞", l: "Configurations" },
];

export function Heritage() {
  return (
    <section className="relative py-32 px-6 md:px-12 border-y border-border">
      <div className="mx-auto max-w-[1400px] grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
        <motion.div
          initial={{ opacity: 0, x: -40 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 1 }}
        >
          <div className="text-[11px] tracking-luxury uppercase text-gold mb-4">Since 1904</div>
          <h2 className="text-5xl md:text-6xl mb-6">A pursuit of<br /><em className="text-gold not-italic">perfection.</em></h2>
          <p className="text-muted-foreground leading-relaxed max-w-md">
            For over a century, Rolls-Royce has been the benchmark of automotive luxury — handcrafted
            in Goodwood, England, by master artisans who treat every motor car as a singular work of art.
          </p>
        </motion.div>

        <div className="grid grid-cols-2 gap-px bg-border">
          {FACTS.map((f, i) => (
            <motion.div
              key={f.l}
              initial={{ opacity: 0, scale: 0.9 }}
              whileInView={{ opacity: 1, scale: 1 }}
              viewport={{ once: true }}
              transition={{ duration: 0.6, delay: i * 0.1 }}
              className="bg-background p-10 text-center hover:bg-card transition-colors"
            >
              <div className="text-5xl md:text-6xl font-display text-gold mb-2">{f.n}</div>
              <div className="text-[10px] tracking-luxury uppercase text-muted-foreground">{f.l}</div>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
