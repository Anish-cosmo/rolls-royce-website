import { createFileRoute } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { ArrowRight, MapPin, Calendar, Compass, Music, Wine } from "lucide-react";
import { SiteHeader } from "@/components/site-header";
import { SiteFooter } from "@/components/site-footer";
import spectreImg from "@/assets/rolls-spectre.jpg";
import ghostImg from "@/assets/rolls-ghost.jpg";

export const Route = createFileRoute("/experience")({
  component: ExperiencePage,
});

const EXPERIENCES = [
  {
    icon: MapPin,
    title: "Goodwood Factory Tour",
    location: "Chichester, England",
    desc: "A private, curated journey through the Home of Rolls-Royce. Witness craftspeople at work, view the production line, and collect your own motor car in person.",
    tag: "By appointment",
  },
  {
    icon: Compass,
    title: "Private Driving Journeys",
    location: "Worldwide",
    desc: "Curated multi-day driving routes through the world's most spectacular landscapes — the Scottish Highlands, the Côte d'Azur, Rajasthan — with a Rolls-Royce waiting at every turn.",
    tag: "Exclusive routes",
  },
  {
    icon: Calendar,
    title: "Owners' Gatherings",
    location: "Global",
    desc: "Invitations to exclusive owner-only events: Goodwood Festival of Speed, Pebble Beach Concours d'Elegance, and private client previews of future models.",
    tag: "Members only",
  },
  {
    icon: Wine,
    title: "Bespoke Hospitality",
    location: "On request",
    desc: "From private château dinners in Bordeaux to exclusive access at Wimbledon and the Royal Opera House — curated cultural experiences for those who live differently.",
    tag: "Invitation only",
  },
  {
    icon: Music,
    title: "Artist Commissions",
    location: "Studio & Goodwood",
    desc: "Collaborate with world-renowned artists and designers to create a truly one-of-one motor car — part sculpture, part transport. The Bespoke Collective brings your vision to life.",
    tag: "Commission based",
  },
];

function ExperiencePage() {
  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />

      {/* Hero */}
      <section className="relative min-h-screen overflow-hidden gradient-radial-dark flex items-end">
        <motion.h2
          initial={{ opacity: 0, scale: 1.05 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1.6 }}
          className="absolute inset-x-0 top-[14%] text-center text-[13vw] leading-none font-display text-stroke-faint pointer-events-none select-none"
        >
          EXPERIENCE
        </motion.h2>
        <motion.img
          src={spectreImg}
          alt="Rolls-Royce Experience"
          initial={{ scale: 1.1, opacity: 0 }}
          animate={{ scale: 1, opacity: 0.55 }}
          transition={{ duration: 1.8, ease: [0.16, 1, 0.3, 1] }}
          className="absolute inset-0 w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/40 to-transparent" />
        <div className="relative z-10 px-6 md:px-12 pb-20 mx-auto max-w-[1500px] w-full">
          <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.6, duration: 1 }}>
            <div className="text-[11px] tracking-luxury uppercase text-gold mb-4">The World of Rolls-Royce</div>
            <h1 className="text-5xl md:text-8xl leading-[1.0]">Beyond<br />the motor car.</h1>
            <p className="mt-4 text-muted-foreground max-w-md text-sm leading-relaxed">
              Rolls-Royce is not a car company. It is an invitation to live differently.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Intro */}
      <section className="py-32 px-6 md:px-12 bg-background">
        <div className="mx-auto max-w-[1500px] grid grid-cols-1 lg:grid-cols-2 gap-20 items-center">
          <motion.div initial={{ opacity: 0, x: -40 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ duration: 0.9 }}>
            <div className="text-[11px] tracking-luxury uppercase text-gold mb-6">A Life Less Ordinary</div>
            <h2 className="text-4xl md:text-5xl mb-8">Moments that<br />define a lifetime.</h2>
            <p className="text-sm text-muted-foreground leading-relaxed mb-4">
              The Rolls-Royce experience extends far beyond the motor car. It is a passport to the world's most exclusive places, events, and encounters — reserved for those who have earned the right to the extraordinary.
            </p>
            <p className="text-sm text-muted-foreground leading-relaxed">
              From private factory tours to curated driving journeys across continents, from artist collaborations to invitation-only cultural events — the Rolls-Royce world is yours to explore.
            </p>
          </motion.div>
          <motion.div initial={{ opacity: 0, x: 40 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ duration: 0.9, delay: 0.15 }}>
            <div className="relative h-[400px] overflow-hidden">
              <img src={ghostImg} alt="Experience" className="absolute inset-0 w-full h-full object-cover" />
              <div className="absolute inset-0 bg-gradient-to-t from-background/60 to-transparent" />
            </div>
          </motion.div>
        </div>
      </section>

      {/* Experiences */}
      <section className="py-32 px-6 md:px-12 bg-card/20 border-y border-border">
        <div className="mx-auto max-w-[1500px]">
          <motion.div initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.8 }}>
            <div className="text-[11px] tracking-luxury uppercase text-gold mb-4">Curated for You</div>
            <h2 className="text-5xl md:text-6xl mb-16">Select experiences.</h2>
          </motion.div>
          <div className="space-y-px">
            {EXPERIENCES.map((exp, i) => (
              <motion.div
                key={exp.title}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.7, delay: i * 0.08 }}
                className="bg-background hover:bg-card transition-colors group"
              >
                <div className="flex flex-col md:flex-row md:items-center gap-6 p-8 md:p-10">
                  <div className="shrink-0">
                    <exp.icon className="h-6 w-6 text-gold" />
                  </div>
                  <div className="flex-1">
                    <div className="flex flex-col md:flex-row md:items-center gap-2 md:gap-6 mb-2">
                      <h3 className="text-2xl">{exp.title}</h3>
                      <div className="flex items-center gap-2">
                        <span className="text-[9px] tracking-luxury uppercase text-gold border border-gold/40 px-2 py-1">{exp.tag}</span>
                        <span className="text-[10px] tracking-luxury uppercase text-muted-foreground">{exp.location}</span>
                      </div>
                    </div>
                    <p className="text-sm text-muted-foreground leading-relaxed max-w-2xl">{exp.desc}</p>
                  </div>
                  <div className="shrink-0">
                    <button className="group/btn inline-flex items-center gap-2 text-[11px] tracking-luxury uppercase text-foreground/40 group-hover:text-gold transition-colors">
                      Enquire
                      <ArrowRight className="h-3 w-3 group-hover/btn:translate-x-1 transition-transform" />
                    </button>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Full width section */}
      <section className="relative h-[60vh] overflow-hidden">
        <img src={spectreImg} alt="The Spectre Experience" className="absolute inset-0 w-full h-full object-cover" style={{ objectPosition: "center 30%" }} />
        <div className="absolute inset-0 bg-gradient-to-r from-background via-background/50 to-transparent" />
        <div className="absolute inset-0 flex items-center px-6 md:px-12">
          <div className="mx-auto max-w-[1500px] w-full">
            <motion.div initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.8 }}>
              <div className="text-[11px] tracking-luxury uppercase text-gold mb-4">Invitation Only</div>
              <h2 className="text-4xl md:text-6xl max-w-lg">The Spectre<br />Unveiling Tour.</h2>
              <p className="text-sm text-muted-foreground mt-4 max-w-sm leading-relaxed">
                Join us for an exclusive first encounter with the fully electric future of Rolls-Royce.
              </p>
              <button className="group mt-8 inline-flex items-center gap-3 text-[11px] tracking-luxury uppercase text-gold">
                Request an Invitation
                <span className="h-px w-8 bg-gold transition-all group-hover:w-14" />
                <ArrowRight className="h-3 w-3" />
              </button>
            </motion.div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 px-6 md:px-12 border-t border-border bg-card/20">
        <div className="mx-auto max-w-[1500px] flex flex-col md:flex-row items-center justify-between gap-8">
          <div>
            <h2 className="text-3xl md:text-4xl">Begin your experience.</h2>
            <p className="text-sm text-muted-foreground mt-2">Speak with a Rolls-Royce curator to personalise your world.</p>
          </div>
          <button className="group inline-flex items-center gap-3 bg-gold text-gold-foreground px-8 py-4 text-[11px] tracking-luxury uppercase hover:bg-foreground transition-colors">
            Get in Touch
            <ArrowRight className="h-3 w-3 group-hover:translate-x-1 transition-transform" />
          </button>
        </div>
      </section>

      <SiteFooter />
    </div>
  );
}
