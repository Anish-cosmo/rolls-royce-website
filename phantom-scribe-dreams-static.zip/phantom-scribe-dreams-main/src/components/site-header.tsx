import { Link } from "@tanstack/react-router";
import { motion, AnimatePresence } from "framer-motion";
import { Menu, User, X } from "lucide-react";
import { useState } from "react";

const NAV = [
  { to: "/", label: "Home" },
  { to: "/models/", label: "Models" },
  { to: "/brand", label: "Brand" },
  { to: "/ownership", label: "Ownership" },
  { to: "/experience", label: "Experience" },
];

export function SiteHeader() {
  const [mobileOpen, setMobileOpen] = useState(false);

  return (
    <>
      <motion.header
        initial={{ y: -40, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.8, ease: [0.16, 1, 0.3, 1] }}
        className="fixed top-0 inset-x-0 z-50"
      >
        <div className="mx-auto flex max-w-[1600px] items-center justify-between px-6 py-5 md:px-12">
          {/* Desktop/Tablet: logo area left, nav center, sign in right */}
          {/* Mobile: hamburger left, sign in right */}

          {/* Hamburger — mobile only */}
          <button
            className="md:hidden text-foreground/80 hover:text-gold transition-colors"
            onClick={() => setMobileOpen(true)}
            aria-label="Open menu"
          >
            <Menu className="h-5 w-5" />
          </button>

          {/* Nav — desktop/tablet only */}
          <nav className="hidden md:flex items-center gap-10 text-[11px] tracking-luxury uppercase">
            {NAV.map((n) => (
              <Link
                key={n.to}
                to={n.to}
                className="hover-gold-line text-foreground/70 hover:text-foreground transition-colors"
                activeProps={{ className: "text-gold" }}
              >
                {n.label}
              </Link>
            ))}
          </nav>

          <div className="flex items-center gap-5">
            <Link
              to="/signin"
              className="flex items-center gap-2 text-[11px] tracking-luxury uppercase text-foreground/80 hover:text-gold transition-colors"
            >
              <User className="h-4 w-4" />
              <span className="hidden sm:inline">Sign In</span>
            </Link>
          </div>
        </div>
        <div className="h-px gradient-gold-line opacity-30" />
      </motion.header>

      {/* Mobile full-screen menu */}
      <AnimatePresence>
        {mobileOpen && (
          <motion.div
            initial={{ opacity: 0, x: "-100%" }}
            animate={{ opacity: 1, x: 0 }}
            exit={{ opacity: 0, x: "-100%" }}
            transition={{ duration: 0.4, ease: [0.16, 1, 0.3, 1] }}
            className="fixed inset-0 z-[100] bg-background flex flex-col"
          >
            <div className="flex items-center justify-between px-6 py-5">
              <span className="text-[11px] tracking-luxury uppercase text-gold">Menu</span>
              <button
                onClick={() => setMobileOpen(false)}
                className="text-foreground/80 hover:text-gold transition-colors"
                aria-label="Close menu"
              >
                <X className="h-5 w-5" />
              </button>
            </div>
            <div className="h-px gradient-gold-line opacity-30" />
            <nav className="flex flex-col gap-8 px-6 pt-12">
              {NAV.map((n, i) => (
                <motion.div
                  key={n.to}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ delay: i * 0.07, duration: 0.4 }}
                >
                  <Link
                    to={n.to}
                    className="text-4xl font-display text-foreground/80 hover:text-gold transition-colors"
                    activeProps={{ className: "text-gold" }}
                    onClick={() => setMobileOpen(false)}
                  >
                    {n.label}
                  </Link>
                </motion.div>
              ))}
            </nav>
          </motion.div>
        )}
      </AnimatePresence>
    </>
  );
}
