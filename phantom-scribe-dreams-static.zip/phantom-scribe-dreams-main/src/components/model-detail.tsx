import { motion } from "framer-motion";
import { ArrowRight, ArrowLeft, Check, Star, Fuel, Zap, Settings, Shield, Palette, ChevronDown, ChevronUp } from "lucide-react";
import { Link } from "@tanstack/react-router";
import { useState } from "react";
import { SiteHeader } from "@/components/site-header";
import { SiteFooter } from "@/components/site-footer";

interface Spec {
  label: string;
  value: string;
  icon?: React.ComponentType<{ className?: string }>;
}

interface Feature {
  category: string;
  items: string[];
}

interface Variant {
  name: string;
  price: string;
  highlight?: boolean;
}

interface ModelDetailProps {
  name: string;
  tagline: string;
  tag: string;
  year: string;
  description: string[];
  img: string;
  heroWord: string;
  specs: Spec[];
  features: Feature[];
  variants: Variant[];
  rating: number;
  priceFrom: string;
  colorOptions: { name: string; hex: string }[];
}

function StarRating({ rating }: { rating: number }) {
  return (
    <div className="flex items-center gap-1">
      {[1, 2, 3, 4, 5].map((s) => (
        <Star
          key={s}
          className={`h-3 w-3 ${s <= rating ? "fill-gold text-gold" : "text-border"}`}
        />
      ))}
      <span className="ml-2 text-[10px] tracking-luxury uppercase text-muted-foreground">{rating}.0 / 5</span>
    </div>
  );
}

export function ModelDetail({
  name,
  tagline,
  tag,
  year,
  description,
  img,
  heroWord,
  specs,
  features,
  variants,
  rating,
  priceFrom,
  colorOptions,
}: ModelDetailProps) {
  const [openFeature, setOpenFeature] = useState<number | null>(0);
  const [activeTab, setActiveTab] = useState<"overview" | "specs" | "features" | "variants">("overview");

  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />

      {/* ── HERO ── */}
      <section className="relative min-h-screen overflow-hidden gradient-radial-dark">
        <motion.h2
          initial={{ opacity: 0, scale: 1.05 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1.6, ease: [0.16, 1, 0.3, 1] }}
          className="absolute inset-x-0 top-[14%] text-center text-[18vw] leading-none font-display text-stroke-faint pointer-events-none select-none"
        >
          {heroWord}
        </motion.h2>

        <motion.div
          initial={{ y: 60, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ duration: 1.2, delay: 0.3, ease: [0.16, 1, 0.3, 1] }}
          className="absolute inset-x-0 top-[16%] flex justify-center"
        >
          <img
            src={img}
            alt={`Rolls-Royce ${name}`}
            className="w-[88%] max-w-[1300px] object-contain drop-shadow-[0_40px_100px_rgba(0,0,0,0.8)]"
          />
        </motion.div>

        <div className="absolute inset-x-0 bottom-0 px-6 md:px-12 pb-10">
          <div className="mx-auto max-w-[1500px]">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 1, delay: 0.8 }}
              className="flex flex-col md:flex-row md:items-end md:justify-between gap-6"
            >
              <div>
                <div className="text-[10px] tracking-luxury uppercase text-gold mb-2">{year} · {tag}</div>
                <h1 className="text-5xl md:text-7xl leading-[1.0]">
                  Rolls-Royce<br />{name}
                </h1>
                <p className="mt-3 text-sm text-muted-foreground max-w-sm">{tagline}</p>
                <div className="mt-3">
                  <StarRating rating={rating} />
                </div>
              </div>
              <div className="flex flex-col items-start md:items-end gap-4">
                <div>
                  <div className="text-[10px] tracking-luxury uppercase text-muted-foreground mb-1">Starting From</div>
                  <div className="text-3xl font-display text-gold">{priceFrom}</div>
                </div>
                <button className="group inline-flex items-center gap-3 bg-gold text-gold-foreground px-8 py-4 text-[11px] tracking-luxury uppercase hover:bg-foreground transition-colors">
                  Configure Yours
                  <ArrowRight className="h-3 w-3 group-hover:translate-x-1 transition-transform" />
                </button>
              </div>
            </motion.div>
          </div>
        </div>
      </section>

      {/* ── STICKY TABS ── */}
      <div className="sticky top-[62px] z-40 bg-background border-b border-border">
        <div className="mx-auto max-w-[1500px] px-6 md:px-12">
          <div className="flex gap-8 overflow-x-auto scrollbar-hide">
            {(["overview", "specs", "features", "variants"] as const).map((tab) => (
              <button
                key={tab}
                onClick={() => setActiveTab(tab)}
                className={`py-4 text-[11px] tracking-luxury uppercase whitespace-nowrap border-b-2 transition-all ${
                  activeTab === tab
                    ? "border-gold text-gold"
                    : "border-transparent text-muted-foreground hover:text-foreground"
                }`}
              >
                {tab}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* ── OVERVIEW ── */}
      <section id="overview" className="py-24 px-6 md:px-12 bg-background">
        <div className="mx-auto max-w-[1500px]">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-20 items-start">
            <motion.div
              initial={{ opacity: 0, x: -40 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.9 }}
            >
              <div className="text-[11px] tracking-luxury uppercase text-gold mb-6">About the {name}</div>
              <h2 className="text-4xl md:text-5xl mb-8 leading-tight">Crafted for those<br />who seek the extraordinary.</h2>
              {description.map((para, i) => (
                <p key={i} className="text-sm text-muted-foreground leading-relaxed mb-5">{para}</p>
              ))}
              <div className="mt-8 flex gap-4">
                <button className="group inline-flex items-center gap-3 text-[11px] tracking-luxury uppercase text-gold">
                  Request a Brochure
                  <span className="h-px w-8 bg-gold transition-all group-hover:w-14" />
                  <ArrowRight className="h-3 w-3" />
                </button>
              </div>
            </motion.div>

            {/* Quick Spec Cards */}
            <motion.div
              initial={{ opacity: 0, x: 40 }}
              whileInView={{ opacity: 1, x: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.9, delay: 0.15 }}
              className="grid grid-cols-2 gap-px bg-border"
            >
              {specs.slice(0, 6).map((spec) => (
                <div key={spec.label} className="bg-background p-8 group hover:bg-card transition-colors">
                  {spec.icon && <spec.icon className="h-4 w-4 text-gold mb-3" />}
                  <div className="text-[10px] tracking-luxury uppercase text-muted-foreground mb-2">{spec.label}</div>
                  <div className="text-2xl font-display">{spec.value}</div>
                </div>
              ))}
            </motion.div>
          </div>
        </div>
      </section>

      {/* ── FULL-WIDTH IMAGE BANNER ── */}
      <section className="relative h-[65vh] overflow-hidden">
        <img
          src={img}
          alt={`Rolls-Royce ${name} — Side Profile`}
          className="absolute inset-0 w-full h-full object-cover object-center scale-105"
          style={{ objectPosition: "center 40%" }}
        />
        <div className="absolute inset-0 bg-gradient-to-r from-background via-background/50 to-transparent" />
        <div className="absolute inset-0 flex items-center px-6 md:px-12">
          <div className="mx-auto max-w-[1500px] w-full">
            <motion.div
              initial={{ opacity: 0, y: 30 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.8 }}
            >
              <div className="text-[11px] tracking-luxury uppercase text-gold mb-4">Exterior Design</div>
              <h2 className="text-4xl md:text-6xl max-w-lg leading-tight">Presence that<br />commands silence.</h2>
              <button className="group mt-8 inline-flex items-center gap-3 text-[11px] tracking-luxury uppercase text-gold">
                Book a Viewing
                <span className="h-px w-8 bg-gold transition-all group-hover:w-14" />
                <ArrowRight className="h-3 w-3" />
              </button>
            </motion.div>
          </div>
        </div>
      </section>

      {/* ── COLOUR OPTIONS ── */}
      <section className="py-24 px-6 md:px-12 bg-card/30">
        <div className="mx-auto max-w-[1500px]">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <div className="text-[11px] tracking-luxury uppercase text-gold mb-4">Bespoke Colour</div>
            <h2 className="text-4xl md:text-5xl mb-12">Choose your palette.</h2>
            <div className="flex flex-wrap gap-6">
              {colorOptions.map((c) => (
                <div key={c.name} className="flex flex-col items-center gap-3 group cursor-pointer">
                  <div
                    className="h-14 w-14 rounded-full border-2 border-border group-hover:border-gold transition-colors shadow-lg"
                    style={{ backgroundColor: c.hex }}
                  />
                  <span className="text-[9px] tracking-luxury uppercase text-muted-foreground group-hover:text-gold transition-colors">{c.name}</span>
                </div>
              ))}
              <div className="flex flex-col items-center gap-3 group cursor-pointer">
                <div className="h-14 w-14 rounded-full border-2 border-dashed border-border group-hover:border-gold transition-colors flex items-center justify-center">
                  <Palette className="h-5 w-5 text-muted-foreground group-hover:text-gold transition-colors" />
                </div>
                <span className="text-[9px] tracking-luxury uppercase text-muted-foreground group-hover:text-gold transition-colors">Bespoke</span>
              </div>
            </div>
          </motion.div>
        </div>
      </section>

      {/* ── FULL SPECS TABLE ── */}
      <section id="specs" className="py-24 px-6 md:px-12 bg-background">
        <div className="mx-auto max-w-[1500px]">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <div className="text-[11px] tracking-luxury uppercase text-gold mb-4">Technical Data</div>
            <h2 className="text-4xl md:text-5xl mb-12">Full Specifications.</h2>
            <div className="divide-y divide-border border-t border-b border-border">
              {specs.map((spec, i) => (
                <motion.div
                  key={spec.label}
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.5, delay: i * 0.04 }}
                  className="flex items-center justify-between py-5 group hover:bg-card/40 px-4 -mx-4 transition-colors"
                >
                  <div className="flex items-center gap-4">
                    {spec.icon && <spec.icon className="h-4 w-4 text-gold/50 group-hover:text-gold transition-colors" />}
                    <span className="text-[11px] tracking-luxury uppercase text-muted-foreground">{spec.label}</span>
                  </div>
                  <span className="text-sm font-display text-foreground">{spec.value}</span>
                </motion.div>
              ))}
            </div>
          </motion.div>
        </div>
      </section>

      {/* ── FEATURES ACCORDION ── */}
      <section id="features" className="py-24 px-6 md:px-12 bg-card/20">
        <div className="mx-auto max-w-[1500px]">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <div className="text-[11px] tracking-luxury uppercase text-gold mb-4">Appointments</div>
            <h2 className="text-4xl md:text-5xl mb-12">Standard Features.</h2>
            <div className="space-y-px">
              {features.map((feat, i) => (
                <div key={feat.category} className="bg-background border border-border/50">
                  <button
                    onClick={() => setOpenFeature(openFeature === i ? null : i)}
                    className="w-full flex items-center justify-between px-8 py-6 text-left hover:bg-card/40 transition-colors"
                  >
                    <span className="text-[11px] tracking-luxury uppercase">{feat.category}</span>
                    {openFeature === i
                      ? <ChevronUp className="h-4 w-4 text-gold" />
                      : <ChevronDown className="h-4 w-4 text-muted-foreground" />
                    }
                  </button>
                  {openFeature === i && (
                    <motion.div
                      initial={{ opacity: 0, height: 0 }}
                      animate={{ opacity: 1, height: "auto" }}
                      exit={{ opacity: 0, height: 0 }}
                      className="px-8 pb-8"
                    >
                      <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-4 border-t border-border/30">
                        {feat.items.map((item) => (
                          <div key={item} className="flex items-start gap-3">
                            <Check className="h-3 w-3 text-gold mt-0.5 shrink-0" />
                            <span className="text-xs text-muted-foreground leading-relaxed">{item}</span>
                          </div>
                        ))}
                      </div>
                    </motion.div>
                  )}
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      </section>

      {/* ── VARIANTS / PRICING ── */}
      <section id="variants" className="py-24 px-6 md:px-12 bg-background">
        <div className="mx-auto max-w-[1500px]">
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.8 }}
          >
            <div className="text-[11px] tracking-luxury uppercase text-gold mb-4">Configurations</div>
            <h2 className="text-4xl md:text-5xl mb-12">Select your variant.</h2>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-px bg-border">
              {variants.map((v) => (
                <div
                  key={v.name}
                  className={`relative p-10 flex flex-col gap-6 transition-colors ${
                    v.highlight ? "bg-card" : "bg-background hover:bg-card/50"
                  }`}
                >
                  {v.highlight && (
                    <div className="absolute top-0 left-0 right-0 h-0.5 bg-gold" />
                  )}
                  {v.highlight && (
                    <div className="text-[9px] tracking-luxury uppercase text-gold mb-2">Most Popular</div>
                  )}
                  <div>
                    <h3 className="text-2xl font-display mb-1">{v.name}</h3>
                    <div className="text-xl text-gold font-display">{v.price}</div>
                  </div>
                  <button className="group inline-flex items-center gap-3 text-[11px] tracking-luxury uppercase text-foreground/60 hover:text-gold transition-colors mt-auto">
                    Enquire
                    <ArrowRight className="h-3 w-3 group-hover:translate-x-1 transition-transform" />
                  </button>
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      </section>

      {/* ── CTA STRIP ── */}
      <section className="py-20 px-6 md:px-12 border-t border-border bg-card/20">
        <div className="mx-auto max-w-[1500px] flex flex-col md:flex-row items-center justify-between gap-8">
          <div>
            <h2 className="text-3xl md:text-4xl">Ready to own a {name}?</h2>
            <p className="text-sm text-muted-foreground mt-2">Visit your nearest Rolls-Royce dealership or configure online.</p>
          </div>
          <div className="flex flex-col sm:flex-row gap-4">
            <button className="group inline-flex items-center gap-3 bg-gold text-gold-foreground px-8 py-4 text-[11px] tracking-luxury uppercase hover:bg-foreground transition-colors">
              Book a Test Drive
              <ArrowRight className="h-3 w-3 group-hover:translate-x-1 transition-transform" />
            </button>
            <button className="group inline-flex items-center gap-3 border border-border px-8 py-4 text-[11px] tracking-luxury uppercase hover:border-gold hover:text-gold transition-colors">
              Find a Dealer
            </button>
          </div>
        </div>
      </section>

      {/* ── BACK NAV ── */}
      <div className="px-6 md:px-12 py-10 bg-background">
        <div className="mx-auto max-w-[1500px]">
          <Link
            to="/models/"
            className="inline-flex items-center gap-3 text-[11px] tracking-luxury uppercase text-foreground/50 hover:text-gold transition-colors"
          >
            <ArrowLeft className="h-3 w-3" />
            Back to all models
          </Link>
        </div>
      </div>

      <SiteFooter />
    </div>
  );
}
