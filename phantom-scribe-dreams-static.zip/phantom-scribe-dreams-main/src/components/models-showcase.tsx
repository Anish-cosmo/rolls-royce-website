import { motion } from "framer-motion";
import { ArrowUpRight } from "lucide-react";
import { Link } from "@tanstack/react-router";
import ghost from "@/assets/rolls-ghost.jpg";
import cullinan from "@/assets/rolls-cullinan.jpg";
import spectre from "@/assets/rolls-spectre.jpg";

const MODELS = [
  { name: "Ghost", tag: "Sedan", year: "2025", img: ghost, desc: "Post Opulent minimalism, redefined.", slug: "ghost" },
  { name: "Cullinan", tag: "SUV", year: "2025", img: cullinan, desc: "Effortless everywhere. Anywhere.", slug: "cullinan" },
  { name: "Spectre", tag: "Coupé · EV", year: "2025", img: spectre, desc: "The first fully electric Rolls-Royce.", slug: "spectre" },
];

export function ModelsShowcase() {
  return (
    <section className="relative py-32 px-6 md:px-12 bg-background">
      <div className="mx-auto max-w-[1500px]">
        <motion.div
          initial={{ opacity: 0, y: 30 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-100px" }}
          transition={{ duration: 0.8 }}
          className="flex items-end justify-between mb-16"
        >
          <div>
            <div className="text-[11px] tracking-luxury uppercase text-gold mb-4">The Collection</div>
            <h2 className="text-5xl md:text-6xl">Discover the<br />Rolls-Royce range.</h2>
          </div>
          <a className="hidden md:inline-flex items-center gap-3 text-[11px] tracking-luxury uppercase text-foreground/70 hover-gold-line">
            View all models <ArrowUpRight className="h-4 w-4" />
          </a>
        </motion.div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
          {MODELS.map((m, i) => (
            <motion.article
              key={m.name}
              initial={{ opacity: 0, y: 60 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-80px" }}
              transition={{ duration: 0.8, delay: i * 0.15, ease: [0.16, 1, 0.3, 1] }}
              className="group cursor-pointer"
            >
              <Link to={`/models/${m.slug}`} className="block">
                <div className="relative w-full aspect-[4/3] overflow-hidden bg-card mb-5">
                  <img
                    src={m.img}
                    alt={m.name}
                    loading="lazy"
                    className="absolute inset-0 h-full w-full object-cover object-center transition-transform duration-[1200ms] ease-out group-hover:scale-110"
                  />
                  <div className="absolute inset-0 bg-gradient-to-t from-background/80 via-transparent to-transparent" />
                  <div className="absolute top-4 left-4 text-[10px] tracking-luxury uppercase text-gold">{m.year}</div>
                </div>
                <div className="flex items-start justify-between">
                  <div>
                    <div className="text-[10px] tracking-luxury uppercase text-muted-foreground mb-1">{m.tag}</div>
                    <h3 className="text-3xl">{m.name}</h3>
                    <p className="text-sm text-muted-foreground mt-2">{m.desc}</p>
                  </div>
                  <ArrowUpRight className="h-5 w-5 text-foreground/40 group-hover:text-gold group-hover:rotate-12 transition-all" />
                </div>
              </Link>
            </motion.article>
          ))}
        </div>
      </div>
    </section>
  );
}
