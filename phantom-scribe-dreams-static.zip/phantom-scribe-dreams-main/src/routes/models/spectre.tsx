import { createFileRoute } from "@tanstack/react-router";
import { Fuel, Gauge, Settings, Zap, Shield } from "lucide-react";
import { ModelDetail } from "@/components/model-detail";
import spectre from "@/assets/rolls-spectre.jpg";

export const Route = createFileRoute("/models/spectre")({
  component: SpectrePage,
});

function SpectrePage() {
  return (
    <ModelDetail
      name="Spectre"
      tagline="The first fully electric Rolls-Royce."
      tag="Electric Super Coupé"
      year="2025"
      heroWord="SPECTRE"
      img={spectre}
      rating={5}
      priceFrom="₹ 7.50 Crore"
      description={[
        "Spectre is the world's first ultra-luxury electric super coupé. It is the most technologically advanced, most emotionally engaging Rolls-Royce ever built — the natural culmination of 118 years of engineering excellence, reimagined for an electric future.",
        "With a dual-motor electric powertrain producing the equivalent of 577 bhp and a staggering 900 Nm of instantly available torque, Spectre delivers effortless, near-silent acceleration that redefines the Rolls-Royce experience. The result is a sensation unlike any petrol motor car — a thrust that is total, immediate, and utterly serene.",
        "Every component has been re-engineered from first principles. The aerodynamic body has a drag coefficient of just 0.26 Cd — the most aerodynamic Rolls-Royce ever made. Yet it remains unmistakably a Rolls-Royce, with the iconic Pantheon grille, Spirit of Ecstasy, and proportions that speak of effortless authority.",
        "On a single charge, Spectre can traverse the length of England — or the breadth of France — arriving at its destination as quietly as it departed. This is not the future of luxury. It is the future of Rolls-Royce.",
      ]}
      specs={[
        { label: "Powertrain", value: "Dual Motor (Front + Rear)", icon: Zap },
        { label: "Power", value: "577 bhp / 430 kW", icon: Zap },
        { label: "Torque", value: "900 Nm (Instant)", icon: Settings },
        { label: "0–100 km/h", value: "4.5 seconds", icon: Gauge },
        { label: "Top Speed", value: "250 km/h (Limited)", icon: Gauge },
        { label: "Drive System", value: "All-Wheel Drive", icon: Settings },
        { label: "Battery Capacity", value: "102 kWh (usable)", icon: Zap },
        { label: "Range (WLTP)", value: "530 km", icon: Fuel },
        { label: "Charging (DC Fast)", value: "195 kW max (0–80% in 34 min)", icon: Zap },
        { label: "Charging (AC)", value: "22 kW onboard", icon: Zap },
        { label: "Wheelbase", value: "3,210 mm", icon: Shield },
        { label: "Length", value: "5,475 mm", icon: Shield },
        { label: "Width", value: "2,144 mm (with mirrors)", icon: Shield },
        { label: "Height", value: "1,475 mm", icon: Shield },
        { label: "Kerb Weight", value: "2,975 kg", icon: Shield },
        { label: "Drag Coefficient", value: "0.26 Cd", icon: Shield },
      ]}
      features={[
        {
          category: "Exterior",
          items: [
            "Illuminated Pantheon grille",
            "Full LED adaptive matrix headlamps",
            "Flush door handles (power deployable)",
            "21-inch aerodynamic alloy wheels",
            "Panoramic glass roof (fixed)",
            "Hidden charging port with auto-cover",
            "Aerodynamic underbody panels",
            "Active air intake control",
            "Spirit of Ecstasy with integrated lighting",
          ],
        },
        {
          category: "Interior & Comfort",
          items: [
            "Starlight Headliner with 4,796 fibre optic lights",
            "Gallery Dashboard — open-pore wood or metal",
            "Heated, ventilated & massaging seats",
            "Four-zone climate control with air ionisation",
            "Leather-lined boot lid interior",
            "Acoustic triple-glazed glass",
            "Power-closing coach doors",
            "Illuminated Fascia with star constellation",
            "Bespoke hand-wound clock",
            "Lambswool floor mats",
          ],
        },
        {
          category: "Technology",
          items: [
            "12.3-inch Rolls-Royce touchscreen",
            "Bespoke Audio (18 speakers, 1,300W)",
            "Wireless Apple CarPlay & Android Auto",
            "Head-up display (full colour)",
            "Satellite navigation with EV route planning",
            "Night Vision with pedestrian & animal detection",
            "360-degree cameras with park assist",
            "Remote key with pre-conditioning",
            "Over-the-air software updates",
            "Wi-Fi hotspot",
          ],
        },
        {
          category: "Safety & Driver Assistance",
          items: [
            "Adaptive cruise with stop-and-go",
            "Lane keeping & centring assist",
            "Frontal collision alert with auto brake",
            "Blind spot monitoring",
            "Rear cross-traffic alert",
            "Electronic stability control",
            "8 airbags",
            "Active suspension with predictive scan",
            "Emergency call function (eCall)",
          ],
        },
      ]}
      variants={[
        { name: "Spectre", price: "₹ 7.50 Cr (ex-showroom)" },
        { name: "Spectre Ultimate", price: "₹ 8.20 Cr (ex-showroom)", highlight: true },
        { name: "Spectre Black Badge", price: "₹ 9.00 Cr (ex-showroom)" },
      ]}
      colorOptions={[
        { name: "White Sands", hex: "#EDE8E0" },
        { name: "Andalusian Black", hex: "#1A1A1A" },
        { name: "Arctic Blue", hex: "#B8C8D8" },
        { name: "Emerald Green", hex: "#1A3D2B" },
        { name: "Rose Gold", hex: "#C8907A" },
        { name: "Lyrical Copper", hex: "#9B5C2A" },
      ]}
    />
  );
}
