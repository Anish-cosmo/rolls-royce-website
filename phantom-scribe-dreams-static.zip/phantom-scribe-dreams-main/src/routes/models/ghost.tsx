import { createFileRoute } from "@tanstack/react-router";
import { Fuel, Gauge, Settings, Zap, Shield, Star } from "lucide-react";
import { ModelDetail } from "@/components/model-detail";
import ghost from "@/assets/rolls-ghost.jpg";

export const Route = createFileRoute("/models/ghost")({
  component: GhostPage,
});

function GhostPage() {
  return (
    <ModelDetail
      name="Ghost"
      tagline="Post Opulent minimalism, redefined."
      tag="Sedan"
      year="2025"
      heroWord="GHOST"
      img={ghost}
      rating={5}
      priceFrom="₹ 6.95 Crore"
      description={[
        "The Ghost is the embodiment of post opulent design philosophy — a car that whispers rather than shouts. Born from a desire to distil Rolls-Royce to its very essence, Ghost is the pure expression of what a motor car can be.",
        "Every surface has been crafted to minimise visual noise while maximising tactile pleasure. From the illuminated fascia — a constellation of over 150 individual stars hand-pricked into the dashboard — to the self-closing doors, Ghost rewards those who know what to look for.",
        "Beneath the serene exterior lies a 6.75-litre twin-turbocharged V12 engine producing 563 bhp and an all-wheel drive system that ensures every journey, however spirited, remains effortlessly composed.",
        "The Ghost is not just transportation — it is an extension of personality. A statement made in the quietest possible voice.",
      ]}
      specs={[
        { label: "Engine", value: "6.75L Twin-Turbo V12", icon: Fuel },
        { label: "Power", value: "563 bhp / 420 kW", icon: Zap },
        { label: "Torque", value: "850 Nm @ 1,600 rpm", icon: Settings },
        { label: "0–100 km/h", value: "4.8 seconds", icon: Gauge },
        { label: "Top Speed", value: "250 km/h (Limited)", icon: Gauge },
        { label: "Drive System", value: "All-Wheel Drive", icon: Settings },
        { label: "Transmission", value: "8-Speed Automatic", icon: Settings },
        { label: "Wheelbase", value: "3,295 mm (Extended: 3,545 mm)", icon: Shield },
        { label: "Length", value: "5,546 mm", icon: Shield },
        { label: "Width", value: "2,148 mm (with mirrors)", icon: Shield },
        { label: "Height", value: "1,571 mm", icon: Shield },
        { label: "Kerb Weight", value: "2,490 kg", icon: Shield },
        { label: "Fuel Capacity", value: "82 litres", icon: Fuel },
        { label: "Boot Capacity", value: "490 litres", icon: Shield },
        { label: "Suspension (Front)", value: "Double Wishbone, Air Springs", icon: Settings },
        { label: "Suspension (Rear)", value: "Multi-link, Self-Levelling Air", icon: Settings },
      ]}
      features={[
        {
          category: "Exterior",
          items: [
            "Pantheon grille with illuminated surround",
            "LED matrix headlamps with cornering light",
            "Laser light high beam",
            "Power-closing coach doors",
            "Flush door handles",
            "20-inch or 21-inch alloy wheels",
            "Two-coat or three-coat paint finish",
            "Chrome exterior trim",
            "Panoramic sunroof",
          ],
        },
        {
          category: "Interior & Comfort",
          items: [
            "Illuminated Fascia with 150+ starlight points",
            "Gallery Dashboard with open-pore wood",
            "Starlight headliner with shooting star animation",
            "Heated, ventilated & massaging front seats",
            "Heated rear seats with recline function",
            "Four-zone climate control",
            "Rear privacy curtains",
            "Lambswool floor mats",
            "Bespoke clock by Rolls-Royce",
            "Cocktail cabinet (extended wheelbase)",
          ],
        },
        {
          category: "Technology",
          items: [
            "Spirit of Ecstasy Head-Up Display",
            "12.3-inch high-resolution touchscreen",
            "Digital instrument cluster",
            "Bespoke Audio System (18 speakers, 1300W)",
            "Wireless Apple CarPlay & Android Auto",
            "Rear-seat entertainment screens",
            "Night Vision with pedestrian detection",
            "360-degree camera with park assist",
            "Remote key with vehicle status monitoring",
            "Wi-Fi hotspot",
          ],
        },
        {
          category: "Safety & Driver Assistance",
          items: [
            "Adaptive cruise control with stop & go",
            "Lane departure warning & assist",
            "Frontal collision warning with brake assist",
            "Blind spot monitoring",
            "Cross-traffic alert",
            "Active roll stabilisation",
            "8 airbags",
            "Tyre pressure monitoring",
            "Automatic emergency braking",
          ],
        },
      ]}
      variants={[
        { name: "Ghost", price: "₹ 6.95 Cr (ex-showroom)" },
        { name: "Ghost Extended", price: "₹ 7.95 Cr (ex-showroom)", highlight: true },
        { name: "Ghost Black Badge", price: "₹ 8.50 Cr (ex-showroom)" },
      ]}
      colorOptions={[
        { name: "Arctic White", hex: "#F0EDE8" },
        { name: "Andalusian Black", hex: "#1A1A1A" },
        { name: "Moccasin", hex: "#C8A97A" },
        { name: "Salamanca Blue", hex: "#2A3F5F" },
        { name: "Bohemian Red", hex: "#8B1A1A" },
        { name: "English White", hex: "#E8E4DC" },
      ]}
    />
  );
}
