import { createFileRoute } from "@tanstack/react-router";
import { Fuel, Gauge, Settings, Zap, Shield } from "lucide-react";
import { ModelDetail } from "@/components/model-detail";
import cullinan from "@/assets/rolls-cullinan.jpg";

export const Route = createFileRoute("/models/cullinan")({
  component: CullinanPage,
});

function CullinanPage() {
  return (
    <ModelDetail
      name="Cullinan"
      tagline="Effortless everywhere. Anywhere."
      tag="Super-luxury SUV"
      year="2025"
      heroWord="CULLINAN"
      img={cullinan}
      rating={5}
      priceFrom="₹ 6.90 Crore"
      description={[
        "Named after the largest gem-quality rough diamond ever discovered, the Rolls-Royce Cullinan is the world's most luxurious SUV. It is built for those who refuse to compromise — not just on comfort, but on the absolute freedom to go anywhere.",
        "Standing tall with effortless all-terrain capability, the Cullinan commands every road. Its elevated seating position grants a unique perspective of the world, while its air suspension system ensures that the road — however treacherous — is simply irrelevant to those within.",
        "The interior is unmistakably Rolls-Royce: hand-stitched leather, open-pore wood veneers, and a bespoke Starlight Headliner that transforms every journey into a private firmament. The Viewing Suite option converts the rear into a private lounge with a deployable table and two seats facing outward.",
        "Power comes from the same 6.75-litre twin-turbocharged V12 that anchors the entire range, now paired with an all-wheel drive system and self-levelling air suspension tuned specifically for off-road terrain.",
      ]}
      specs={[
        { label: "Engine", value: "6.75L Twin-Turbo V12", icon: Fuel },
        { label: "Power", value: "563 bhp / 420 kW", icon: Zap },
        { label: "Torque", value: "850 Nm @ 1,600 rpm", icon: Settings },
        { label: "0–100 km/h", value: "5.2 seconds", icon: Gauge },
        { label: "Top Speed", value: "250 km/h (Limited)", icon: Gauge },
        { label: "Drive System", value: "All-Wheel Drive + Low Range", icon: Settings },
        { label: "Transmission", value: "8-Speed Automatic", icon: Settings },
        { label: "Wheelbase", value: "3,295 mm", icon: Shield },
        { label: "Length", value: "5,341 mm", icon: Shield },
        { label: "Width", value: "2,164 mm (with mirrors)", icon: Shield },
        { label: "Height", value: "1,835 mm", icon: Shield },
        { label: "Kerb Weight", value: "2,660 kg", icon: Shield },
        { label: "Fuel Capacity", value: "100 litres", icon: Fuel },
        { label: "Boot Capacity", value: "560 litres", icon: Shield },
        { label: "Ground Clearance", value: "Up to 220 mm (adaptive)", icon: Shield },
        { label: "Wading Depth", value: "540 mm", icon: Shield },
      ]}
      features={[
        {
          category: "Exterior",
          items: [
            "Upright Pantheon grille with illuminated surround",
            "Full LED adaptive matrix headlamps",
            "Retractable running boards (powered)",
            "22-inch or 23-inch forged alloy wheels",
            "Power-closing tailgate with valet button",
            "Roof rails in anodised aluminium",
            "Deployable towbar",
            "Heated washer jets",
            "Chrome or Black Badge dark exterior finish",
          ],
        },
        {
          category: "Interior & Comfort",
          items: [
            "Starlight Headliner with 1,344 fibre optic lights",
            "Five-seat or four-seat lounge configuration",
            "Viewing Suite rear option (two rear-facing seats + table)",
            "Heated, ventilated & massaging seats all-round",
            "Individual rear climate zones",
            "Refrigerator drawer in centre console",
            "Lambswool over-rugs",
            "Picnic tables for rear passengers",
            "Bespoke hand-wound clock",
            "Leather-trimmed headlining",
          ],
        },
        {
          category: "Technology",
          items: [
            "12.3-inch high-resolution infotainment",
            "Bespoke Audio (18 speakers, 1,300W)",
            "Rear-seat 10-inch screens",
            "Wireless Apple CarPlay & Android Auto",
            "Head-up display with navigation",
            "Night Vision",
            "360-degree surround camera",
            "Off-road camera (front & rear underbody view)",
            "Satellite navigation with traffic",
            "Wi-Fi hotspot (up to 8 devices)",
          ],
        },
        {
          category: "Safety & Driver Assistance",
          items: [
            "Adaptive cruise with stop-and-go",
            "All-terrain traction control",
            "Active roll stabilisation",
            "Descent control",
            "Blind spot monitoring with rear cross-traffic alert",
            "Lane keeping assist",
            "8 airbags",
            "Tyre Pressure Monitoring System",
            "Emergency call function",
          ],
        },
      ]}
      variants={[
        { name: "Cullinan", price: "₹ 6.90 Cr (ex-showroom)" },
        { name: "Cullinan Series II", price: "₹ 7.90 Cr (ex-showroom)", highlight: true },
        { name: "Cullinan Black Badge", price: "₹ 8.75 Cr (ex-showroom)" },
      ]}
      colorOptions={[
        { name: "Arctic White", hex: "#F0EDE8" },
        { name: "Midnight Emerald", hex: "#1B3A2D" },
        { name: "Andalusian Black", hex: "#1A1A1A" },
        { name: "Sunburst Gold", hex: "#C8991A" },
        { name: "Contour Purple", hex: "#3D2A4F" },
        { name: "Cobalto Blue", hex: "#1A2F6B" },
      ]}
    />
  );
}
