import { createFileRoute } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { ArrowRight } from "lucide-react";
import { SiteHeader } from "@/components/site-header";
import { SiteFooter } from "@/components/site-footer";
import heroImg from "@/assets/rolls-hero.jpg";
import ghostImg from "@/assets/rolls-ghost.jpg";

export const Route = createFileRoute("/brand")({
  component: BrandPage,
});

const MILESTONES = [
  { year: "1904", title: "The Meeting", desc: "Charles Rolls and Henry Royce meet at the Midland Hotel in Manchester. A handshake between engineer and entrepreneur would change motoring forever." },
  { year: "1906", title: "The Silver Ghost", desc: "The Silver Ghost is unveiled — later called 'the best car in the world' by Autocar. It cements Rolls-Royce as the pinnacle of engineering." },
  { year: "1925", title: "The Phantom", desc: "The first Phantom arrives, establishing a lineage of ultra-luxury motor cars that continues to define the brand today." },
  { year: "1950", title: "Goodwood", desc: "Rolls-Royce Motor Cars finds its permanent home in the heart of the West Sussex countryside, where every car is still made by hand today." },
  { year: "2003", title: "New Dawn", desc: "BMW Group opens the Goodwood Home of Rolls-Royce, combining 20th-century craftsmanship with 21st-century engineering." },
  { year: "2023", title: "Spectre", desc: "The Spectre launches as the first fully electric Rolls-Royce — proof that the future of luxury needs no compromise." },
];

const VALUES = [
  { title: "Craftsmanship", desc: "Every Rolls-Royce is hand-assembled in Goodwood, England. Each car takes months to build and involves over 2,000 hours of skilled artisan work." },
  { title: "Bespoke", desc: "No two Rolls-Royces are alike. The Bespoke programme offers limitless personalisation — from hand-painted coachlines to individual interior constellations." },
  { title: "Spirit of Ecstasy", desc: "Since 1911, the Spirit of Ecstasy figurehead has graced every bonnet. Cast from steel and precision-engineered, she remains the world's most recognised automotive icon." },
  { title: "Silence", desc: "Rolls-Royce engineers measure silence in whispers. Every car is tuned to produce the world's quietest cabin — a feat achieved through engineering that borders on obsession." },
];

function BrandPage() {
  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />

      {/* Hero */}
      <section className="relative min-h-screen overflow-hidden gradient-radial-dark flex items-end">
        <motion.h2
          initial={{ opacity: 0, scale: 1.05 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1.6 }}
          className="absolute inset-x-0 top-[14%] text-center text-[18vw] leading-none font-display text-stroke-faint pointer-events-none select-none"
        >
          HERITAGE
        </motion.h2>
        <motion.img
          src={heroImg}
          alt="Rolls-Royce heritage"
          initial={{ scale: 1.1, opacity: 0 }}
          animate={{ scale: 1, opacity: 0.6 }}
          transition={{ duration: 1.8, ease: [0.16, 1, 0.3, 1] }}
          className="absolute inset-0 w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/40 to-transparent" />
        <div className="relative z-10 px-6 md:px-12 pb-20 mx-auto max-w-[1500px] w-full">
          <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.6, duration: 1 }}>
            <div className="text-[11px] tracking-luxury uppercase text-gold mb-4">Since 1904</div>
            <h1 className="text-5xl md:text-8xl leading-[1.0]">The Brand<br />of Brands.</h1>
            <p className="mt-4 text-muted-foreground max-w-md text-sm leading-relaxed">
              For over a century, Rolls-Royce has been synonymous with the very pinnacle of luxury. Not just in motoring — but in the world.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Values */}
      <section className="py-32 px-6 md:px-12 bg-background">
        <div className="mx-auto max-w-[1500px]">
          <motion.div initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.8 }}>
            <div className="text-[11px] tracking-luxury uppercase text-gold mb-4">Our Pillars</div>
            <h2 className="text-5xl md:text-6xl mb-16">What we stand for.</h2>
          </motion.div>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-px bg-border">
            {VALUES.map((v, i) => (
              <motion.div
                key={v.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.7, delay: i * 0.1 }}
                className="bg-background p-12 hover:bg-card transition-colors"
              >
                <div className="text-[10px] tracking-luxury uppercase text-gold mb-4">0{i + 1}</div>
                <h3 className="text-3xl mb-4">{v.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{v.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Timeline */}
      <section className="py-32 px-6 md:px-12 bg-card/20 border-y border-border">
        <div className="mx-auto max-w-[1500px]">
          <motion.div initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.8 }}>
            <div className="text-[11px] tracking-luxury uppercase text-gold mb-4">The Journey</div>
            <h2 className="text-5xl md:text-6xl mb-16">Milestones.</h2>
          </motion.div>
          <div className="relative">
            <div className="absolute left-0 md:left-1/2 top-0 bottom-0 w-px bg-border md:-translate-x-px" />
            <div className="space-y-16">
              {MILESTONES.map((m, i) => (
                <motion.div
                  key={m.year}
                  initial={{ opacity: 0, y: 30 }}
                  whileInView={{ opacity: 1, y: 0 }}
                  viewport={{ once: true }}
                  transition={{ duration: 0.7, delay: i * 0.08 }}
                  className={`relative grid grid-cols-1 md:grid-cols-2 gap-8 ${i % 2 === 0 ? "" : "md:direction-rtl"}`}
                >
                  <div className={`${i % 2 === 0 ? "md:pr-16 md:text-right" : "md:col-start-2 md:pl-16"}`}>
                    <div className="text-[11px] tracking-luxury uppercase text-gold mb-2">{m.year}</div>
                    <h3 className="text-2xl mb-3">{m.title}</h3>
                    <p className="text-sm text-muted-foreground leading-relaxed">{m.desc}</p>
                  </div>
                  <div className={`hidden md:block ${i % 2 !== 0 ? "md:col-start-1 md:row-start-1" : ""}`} />
                  <div className="absolute left-[-5px] md:left-1/2 md:-translate-x-1/2 top-1 h-2.5 w-2.5 rounded-full bg-gold" />
                </motion.div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* Goodwood */}
      <section className="relative h-[60vh] overflow-hidden">
        <img src={ghostImg} alt="Goodwood" className="absolute inset-0 w-full h-full object-cover" style={{ objectPosition: "center 50%" }} />
        <div className="absolute inset-0 bg-gradient-to-r from-background via-background/60 to-transparent" />
        <div className="absolute inset-0 flex items-center px-6 md:px-12">
          <div className="mx-auto max-w-[1500px] w-full">
            <motion.div initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.8 }}>
              <div className="text-[11px] tracking-luxury uppercase text-gold mb-4">Goodwood, England</div>
              <h2 className="text-4xl md:text-6xl max-w-lg">Every car.<br />Handmade. Here.</h2>
              <button className="group mt-8 inline-flex items-center gap-3 text-[11px] tracking-luxury uppercase text-gold">
                Visit Goodwood
                <span className="h-px w-8 bg-gold transition-all group-hover:w-14" />
                <ArrowRight className="h-3 w-3" />
              </button>
            </motion.div>
          </div>
        </div>
      </section>

      <SiteFooter />
    </div>
  );
}
