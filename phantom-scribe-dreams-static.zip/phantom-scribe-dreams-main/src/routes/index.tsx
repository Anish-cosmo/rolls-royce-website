import { createFileRoute } from "@tanstack/react-router";
import { SiteHeader } from "@/components/site-header";
import { Hero } from "@/components/hero";
import { ModelsShowcase } from "@/components/models-showcase";
import { Heritage } from "@/components/heritage";
import { SiteFooter } from "@/components/site-footer";

export const Route = createFileRoute("/")({
  component: Index,
});

function Index() {
  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />
      <main>
        <Hero />
        <ModelsShowcase />
        <Heritage />
      </main>
      <SiteFooter />
    </div>
  );
}
