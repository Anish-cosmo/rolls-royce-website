import { createFileRoute } from "@tanstack/react-router";
import { motion } from "framer-motion";
import { ArrowRight, Shield, Wrench, Phone, Award, Clock, Users } from "lucide-react";
import { SiteHeader } from "@/components/site-header";
import { SiteFooter } from "@/components/site-footer";
import cullinanImg from "@/assets/rolls-cullinan.jpg";

export const Route = createFileRoute("/ownership")({
  component: OwnershipPage,
});

const SERVICES = [
  {
    icon: Shield,
    title: "4-Year Warranty",
    desc: "Every Rolls-Royce comes with a 4-year unlimited mileage warranty as standard. Your peace of mind is guaranteed.",
  },
  {
    icon: Wrench,
    title: "Scheduled Servicing",
    desc: "Our technicians — trained exclusively on Rolls-Royce motor cars — come to you. We collect, service, and return at a time of your choosing.",
  },
  {
    icon: Phone,
    title: "24/7 Roadside Assistance",
    desc: "Round-the-clock support anywhere in the world. A dedicated Rolls-Royce specialist is always on hand.",
  },
  {
    icon: Award,
    title: "Bespoke Aftercare",
    desc: "Your Rolls-Royce is as individual as you are. Our bespoke aftercare team ensures it stays that way — for life.",
  },
  {
    icon: Clock,
    title: "Courtesy Car",
    desc: "Whenever your motor car is in our care, a Rolls-Royce courtesy car is provided. You will never be without.",
  },
  {
    icon: Users,
    title: "Private Ownership Lounge",
    desc: "Access to an exclusive global network of owner events, factory visits, and private previews of upcoming models.",
  },
];

const FAQS = [
  {
    q: "How long does a Rolls-Royce take to build?",
    a: "Each Rolls-Royce requires approximately 2,000 hours of skilled craftwork at our Goodwood Home. From order to delivery, clients typically wait 6–12 months for a bespoke configuration.",
  },
  {
    q: "What does the Bespoke programme cover?",
    a: "Virtually everything. Exterior paint (from a palette of 44,000 colours), interior leather and wood, illuminated fascia constellations, embroidery, personalised treadplates, and even items from your personal collection encapsulated within the motor car.",
  },
  {
    q: "What is the cost of ownership per year?",
    a: "Annual servicing costs vary by model and mileage. Your dealer will provide a personalised ownership plan. Servicing is recommended annually or every 25,000 km, whichever is sooner.",
  },
  {
    q: "Can I visit the Goodwood factory?",
    a: "Yes. The Home of Rolls-Royce in Goodwood offers private tours by appointment. Owners who have commissioned a Bespoke motor car are invited to attend a delivery ceremony at the factory.",
  },
];

function OwnershipPage() {
  return (
    <div className="min-h-screen bg-background">
      <SiteHeader />

      {/* Hero */}
      <section className="relative min-h-screen overflow-hidden gradient-radial-dark flex items-end">
        <motion.h2
          initial={{ opacity: 0, scale: 1.05 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1.6 }}
          className="absolute inset-x-0 top-[14%] text-center text-[14vw] leading-none font-display text-stroke-faint pointer-events-none select-none"
        >
          OWNERSHIP
        </motion.h2>
        <motion.img
          src={cullinanImg}
          alt="Ownership"
          initial={{ scale: 1.1, opacity: 0 }}
          animate={{ scale: 1, opacity: 0.55 }}
          transition={{ duration: 1.8, ease: [0.16, 1, 0.3, 1] }}
          className="absolute inset-0 w-full h-full object-cover"
        />
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/40 to-transparent" />
        <div className="relative z-10 px-6 md:px-12 pb-20 mx-auto max-w-[1500px] w-full">
          <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ delay: 0.6, duration: 1 }}>
            <div className="text-[11px] tracking-luxury uppercase text-gold mb-4">For Our Clients</div>
            <h1 className="text-5xl md:text-8xl leading-[1.0]">A lifetime<br />of service.</h1>
            <p className="mt-4 text-muted-foreground max-w-md text-sm leading-relaxed">
              Owning a Rolls-Royce is the beginning of a relationship — not the end of a purchase.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Services Grid */}
      <section className="py-32 px-6 md:px-12 bg-background">
        <div className="mx-auto max-w-[1500px]">
          <motion.div initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.8 }}>
            <div className="text-[11px] tracking-luxury uppercase text-gold mb-4">What We Offer</div>
            <h2 className="text-5xl md:text-6xl mb-16">Owner services.</h2>
          </motion.div>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-px bg-border">
            {SERVICES.map((s, i) => (
              <motion.div
                key={s.title}
                initial={{ opacity: 0, y: 30 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.7, delay: i * 0.08 }}
                className="bg-background p-10 hover:bg-card transition-colors group"
              >
                <s.icon className="h-6 w-6 text-gold mb-6" />
                <h3 className="text-xl mb-3">{s.title}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed">{s.desc}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* Bespoke highlight */}
      <section className="py-32 px-6 md:px-12 bg-card/20 border-y border-border">
        <div className="mx-auto max-w-[1500px] grid grid-cols-1 lg:grid-cols-2 gap-20 items-center">
          <motion.div initial={{ opacity: 0, x: -40 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ duration: 0.9 }}>
            <div className="text-[11px] tracking-luxury uppercase text-gold mb-6">Bespoke Programme</div>
            <h2 className="text-4xl md:text-5xl mb-6">Yours. Truly.</h2>
            <p className="text-sm text-muted-foreground leading-relaxed mb-4">
              The Rolls-Royce Bespoke programme begins with a single question: what do you want your motor car to say about you? From there, our designers, craftspeople, and client advisors collaborate to create something the world has never seen.
            </p>
            <p className="text-sm text-muted-foreground leading-relaxed mb-8">
              No idea is too ambitious. We have encapsulated family heirlooms into dashboards, hand-painted landscapes across roof linings, and recreated favourite constellations in Starlight Headliners. If you can imagine it, we can build it.
            </p>
            <button className="group inline-flex items-center gap-3 text-[11px] tracking-luxury uppercase text-gold">
              Start Your Commission
              <span className="h-px w-8 bg-gold transition-all group-hover:w-14" />
              <ArrowRight className="h-3 w-3" />
            </button>
          </motion.div>
          <motion.div initial={{ opacity: 0, x: 40 }} whileInView={{ opacity: 1, x: 0 }} viewport={{ once: true }} transition={{ duration: 0.9, delay: 0.15 }}>
            <div className="grid grid-cols-2 gap-px bg-border">
              {[
                { n: "44,000+", l: "Exterior Colour Options" },
                { n: "∞", l: "Interior Configurations" },
                { n: "2,000+", l: "Hours Per Motor Car" },
                { n: "1", l: "Like Yours in the World" },
              ].map((stat) => (
                <div key={stat.l} className="bg-background p-10 text-center hover:bg-card transition-colors">
                  <div className="text-4xl font-display text-gold mb-2">{stat.n}</div>
                  <div className="text-[9px] tracking-luxury uppercase text-muted-foreground">{stat.l}</div>
                </div>
              ))}
            </div>
          </motion.div>
        </div>
      </section>

      {/* FAQ */}
      <section className="py-32 px-6 md:px-12 bg-background">
        <div className="mx-auto max-w-[1500px]">
          <motion.div initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.8 }}>
            <div className="text-[11px] tracking-luxury uppercase text-gold mb-4">Ownership Questions</div>
            <h2 className="text-5xl md:text-6xl mb-16">Frequently asked.</h2>
          </motion.div>
          <div className="divide-y divide-border border-t border-border">
            {FAQS.map((faq, i) => (
              <motion.div
                key={faq.q}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ duration: 0.6, delay: i * 0.08 }}
                className="py-8"
              >
                <h3 className="text-lg mb-3 text-foreground">{faq.q}</h3>
                <p className="text-sm text-muted-foreground leading-relaxed max-w-3xl">{faq.a}</p>
              </motion.div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-20 px-6 md:px-12 border-t border-border bg-card/20">
        <div className="mx-auto max-w-[1500px] flex flex-col md:flex-row items-center justify-between gap-8">
          <div>
            <h2 className="text-3xl md:text-4xl">Speak to an Advisor</h2>
            <p className="text-sm text-muted-foreground mt-2">Our client team is available to answer any question, however detailed.</p>
          </div>
          <div className="flex gap-4">
            <button className="group inline-flex items-center gap-3 bg-gold text-gold-foreground px-8 py-4 text-[11px] tracking-luxury uppercase hover:bg-foreground transition-colors">
              Contact Us
              <ArrowRight className="h-3 w-3 group-hover:translate-x-1 transition-transform" />
            </button>
          </div>
        </div>
      </section>

      <SiteFooter />
    </div>
  );
}
