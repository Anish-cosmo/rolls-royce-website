import { createClient } from "@supabase/supabase-js";

// ─────────────────────────────────────────────────────────────────────────────
// SUPABASE STATUS: NOT CONNECTED
//
// The project was shipped with placeholder credentials. Supabase is NOT
// connected. Sign-in will return an error until you replace the two values
// below with your real project credentials from https://supabase.com/dashboard
//
// Steps:
//  1. Go to https://supabase.com → your project → Settings → API
//  2. Copy "Project URL"  → paste as SUPABASE_URL
//  3. Copy "anon / public" key → paste as SUPABASE_ANON_KEY
//  4. Save the file — the app will hot-reload and auth will work immediately.
// ─────────────────────────────────────────────────────────────────────────────

const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL ?? "https://YOUR-PROJECT-ID.supabase.co";
const SUPABASE_ANON_KEY = import.meta.env.VITE_SUPABASE_ANON_KEY ?? "YOUR-PUBLIC-ANON-KEY";

export const supabase = createClient(SUPABASE_URL, SUPABASE_ANON_KEY, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
  },
});

// Usage note: set VITE_SUPABASE_URL and VITE_SUPABASE_ANON_KEY in your .env
// file to connect without touching this file.
