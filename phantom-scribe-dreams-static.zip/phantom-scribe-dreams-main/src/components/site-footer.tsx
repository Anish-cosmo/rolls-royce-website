export function SiteFooter() {
  return (
    <footer className="border-t border-border py-12 px-6 md:px-12">
      <div className="mx-auto max-w-[1500px] flex flex-col md:flex-row justify-between gap-8 items-start md:items-center">
        <div>
          <div className="font-display text-2xl text-gold tracking-wider">RR</div>
          <p className="text-xs text-muted-foreground mt-2 tracking-wider">ROLLS-ROYCE MOTOR CARS</p>
        </div>
        <div className="flex flex-wrap gap-8 text-[10px] tracking-luxury uppercase text-muted-foreground">
          <a className="hover:text-gold transition-colors">Privacy</a>
          <a className="hover:text-gold transition-colors">Cookies</a>
          <a className="hover:text-gold transition-colors">Press</a>
          <a className="hover:text-gold transition-colors">Careers</a>
          <a className="hover:text-gold transition-colors">Dealers</a>
        </div>
        <div className="text-[10px] tracking-luxury uppercase text-muted-foreground">© 2025 Inspired by Goodwood</div>
      </div>
    </footer>
  );
}
